export const initialDocuments = [
  { id: 1, name: 'Contrato de Arrendamiento', status: 'Pendiente', file: null },
  { id: 2, name: 'Acuerdo de Confidencialidad', status: 'Firmado', signedBy: 'Usuario Demo', file: null },
  { id: 3, name: 'Propuesta de Proyecto', status: 'Pendiente', file: null },
];